<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Youtube Downloader Hub</title>
<link href="stylesheet.css" rel="stylesheet" type="text/css">
<link href="toastr.css" rel="stylesheet" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#4C4C4C">
<meta charset="utf-8">
<title>Youtube Downloader Hub</title>
<meta name="robots" content="index, follow">
<meta name="revisit-after" content="12 month">
<meta name="description" content="Youtube Downloader Hub Is A Free Web Application That Allows You To Download Videos From YouTube.">
<meta name="keywords" content="youtube downloader, video download, youtubedownloader, online video downloader, free online video downloader">
<meta property=”og:image” content=”http://www.ytdhub.ga/data_image/ytdhub-logo-2-min.png”/>
<link rel="icon" href="data_image/data_image/ytdhub-white-min copy-min.png.png">
</head>
<body class="light_black">
<?php
require_once 'Mobile_Detect.php';
$detect=new Mobile_Detect;
if(!$detect->isMobile())
{
	echo '<div class="video_class">
      <video autoplay loop preload="auto" muted="muted" id="back_video">
      <source src="data_image/Molecular Plex 4k Motion Background Loop (1)-1.m4v">
      </video>
</div>';
}
 ?>


<div id="whole">
<!--Header-->
<header class="container-full full dark_black">
	<div class="container_70">
		<div class="left width">
			<a href="index.php"><img src="data_image/ytdhub-white-min.png" class="logo_width" title="Youtube Downloader Hub"></a>
		</div>
		<div class="right width_right">
        <!-- <div class="single_download" style="margin-left:15PX;">
				<center style=""><a href="playlist download.php" style="text-decoration: none; "><div class="txt">playlist</div></a></center>
			</div> -->
			<!-- <div class="single_download active">
				<center style=""><a href="index.php" style="text-decoration: none;"><div class="txt ative">Single</div></a></center>
			</div> -->
		</div>
	</div>
</header>
<!--End Header-->
<center>
<!--body get url part-->
<div style="" class="url">
	<form action="" method="get" id="url_form" name="url_form" >

	    <input type="text" <?php if(!isset($_GET['url']))echo 'placeholder="Enter the Youtube Url"'; else echo 'placeholder="'.$_GET['url'].'"';?> class="txt_box" name="url" id="url" title="Input Youtube Url ">
		<button type="submit" class="dark_black btn" id="submit" onClick="return check()" title="Search For Video Link">Download</button>
	</form>
	</div>
<?php
	if(isset($_GET['url']))
	{
		$url=$_GET['url'];
		if(!filter_var($url, FILTER_VALIDATE_URL) === false)
		{
			$image=get_meta_tags($url);
		    $image_url=$image['twitter:image'];
			$query=parse_url($url);
			$query_val=explode("v=",$query['query']);
			$fetch_data_url="https://www.youtube.com/get_video_info?video_id=".$query_val[1]."&cpn=CouQulsSRICzWn5E&eurl&el=adunit";
		    $data=file_get_contents($fetch_data_url);
			parse_str($data,$arr);

			$data_main=$arr['player_response'];
			$data_main=json_decode($data_main,true);
			$status=$data_main['playabilityStatus']['status']=='OK';
			$title_tumbnail=$data_main['microformat']['playerMicroformatRenderer'];
			$title=$title_tumbnail['title']['simpleText'];
			$thumbnail=$title_tumbnail['thumbnail']['thumbnails'][0]['url'];
			$data_main=$data_main['streamingData']['adaptiveFormats'];
			$i=1;
			
			echo '<div class="dark_black download_back">
		<center>
			<a href="'.$url.'" style="text-decoration:none;" target="_blank"><img src="'.$thumbnail.'" width="500" height="250" class="scr_shot"></a>
			<br><br>
			<div class="width_title txt_title" title="Video Name"><a href="'.$url.'" style="text-decoration:none; color:#fff;" target="_blank">'.$title.'</a></div>
			<br>
			<div class="download_btn">';
			foreach($data_main as $link)
			   {
					 // echo('Url :'.$link['url']);
					 if ($i<=10 && $status==1){
						 if(isset($link['url'])){
							 $type=explode(";",$link['mimeType']);
						   $type_main=explode("/",$type[0]);
							 $type_main=$type_main[1];
						   echo '<div style=""><a href="'.$link['url'].'?title='.$title.'" download><button class="download_video_btn" title="'.$link['qualityLabel'].'"><div class="txt_down">'.$link['qualityLabel'].'('.$type_main.')</div></button></a></div>';
						 }
						 else {
							 parse_str($link['cipher'],$arr_);
							 $type=explode(";",$link['mimeType']);
 							$type_main=explode("/",$type[0]);
 							$type_main=$type_main[1];
 							echo '<div style=""><a href="'.$arr_['url'].'?title='.$title.'" download><button class="download_video_btn" title="'.$link['qualityLabel'].'"><div class="txt_down">'.$link['qualityLabel'].'('.$type_main.')</div></button></a></div>';
						 }


					 }
					 else {
						 echo '<div style=""><a href="#" download><button class="download_video_btn" title="#"><div class="txt_down">-</div></button></a></div>';
					 	break;
					 }
					 $i+=1;

			   }


                      Echo '</div></center></div>';
		}
		else
		{
			header("location:index.php");
		}

	}
	?>
<!--End body get url part-->
<div style="" class="aboutus light_black">
		<div class="txt_about" title="Aboutus">how to download:-</div><br><br>
        <div class="txt_about" title="Aboutus">Youtube Downloader Hub is a free web application that allows you to download videos from YouTube. All you need is the URL of the page that has the video you want to download. Enter it in the textbox above and simply click 'Download'. Youtube Downloader Hub will then fetch download links in all possible formats that the particular site provides.</div>
</div>
<footer class="footer dark_black" id="footer">
	<center>
    	<a href="index.php" style="text-decoration:none;"><div class="txt_title" style="line-height:80px;" title="Copyright">Copyright©<?php echo date('Y'); ?> Youtube Downloader Hub. All Rights Reserved.</div></a>
	</center>
</footer>
</center>
</div>
<div class="loader"></div>
</body>
<script src="jquery-1.8.3.min.js"></script>
<script src="toastr.js"></script>
<script>
$(window).load(function() {
	$(".loader").fadeOut("slow");
});
	function check()
	    {
			var url=document.getElementById("url").value;
			if(url.trim().length==0||url.length==0||url=="")
				    {

						toastr.error("Please Enter The Url");
						return false;
					}
			else {
				return true;
			}
		}
	</script>
</html>
